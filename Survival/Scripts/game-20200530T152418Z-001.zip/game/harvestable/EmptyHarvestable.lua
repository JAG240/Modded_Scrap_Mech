-- EmptyHarvestable.lua --
EmptyHarvestable = class( nil )