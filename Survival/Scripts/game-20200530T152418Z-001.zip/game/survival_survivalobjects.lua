-- survival objects that can not be crafted

obj_debug_cheatchest = sm.uuid.new( "88f402ec-9706-4ad7-9e51-e17b8162cf92" )

-- character shapes
obj_character_worm = sm.uuid.new( "f2aa1e44-aea8-4431-9b7e-f7e35163dd7c" )

-- cookbot food rendables
char_cookbot_food_01 = sm.uuid.new( "4d807f6b-7cdb-41e8-81e2-d87a599422a7" )
char_cookbot_food_02 = sm.uuid.new( "b5cf212b-331e-46e3-9a72-5e8bc2b9a5b7" )
char_cookbot_food_03 = sm.uuid.new( "86128cfa-5c90-4d7c-a9eb-fff9490f9ef9" )
char_cookbot_food_04 = sm.uuid.new( "d22164ab-fba8-4243-9059-77abc82eb995" )